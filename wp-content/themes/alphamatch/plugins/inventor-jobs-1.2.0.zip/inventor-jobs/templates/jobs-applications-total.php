<div class="inventor-jobs-total-applications">
    <i class="fa fa-hand-peace-o"></i> <?php echo sprintf( _n( '<strong>%d</strong> person applied', '<strong>%d</strong> people applied', $total_applications, 'inventor-jobs' ), $total_applications ); ?>
</div>