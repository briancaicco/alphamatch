<div class="form-group review-form-cons">
    <label>
        <i class="fa fa-thumbs-down"></i>
        <?php echo __( 'Cons', 'inventor-reviews' ); ?>
    </label>

    <textarea id="cons"
              name="cons"
              rows="4"></textarea>
</div><!-- /.form-group -->