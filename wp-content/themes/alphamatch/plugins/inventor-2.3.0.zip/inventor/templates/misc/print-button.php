<a href="#" class="print-listing" onclick="window.print(); return false;">
    <i class="fa fa-print"></i> <?php echo __( 'Print', 'inventor' ); ?>
</a><!-- /.print-listing-->