<div class="detail-banner detail-banner-simple">
    <?php include Inventor_Template_Loader::locate( 'content-listing-banner-info' ); ?>
</div><!-- /.detail-banner -->