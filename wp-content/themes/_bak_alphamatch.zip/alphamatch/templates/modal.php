<?php
/**
 * Template file
 *
 * @package Superlist
 * @subpackage Templates
 */

?>

<div class="modal-screen">
	<div class="modal-close"><i class="fa fa-close"></i></div><!-- /.modal-screen -->
	<div class="modal-main"></div><!-- /.modal-main -->
</div><!-- /.modal-screen -->
