<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly.
}

?>

	  
<div id="fep-menu">

	<?php //do_action('fep_menu_button'); ?>

</div><!--#fep-menu -->

<div id="fep-content">
	  
	<?php do_action('fep_display_before_content'); ?>

