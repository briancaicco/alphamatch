

		<?php if ( has_nav_menu( 'main' ) ) : ?>
		    <?php wp_nav_menu( array(
		        'container_class'   => 'mainNavToggle',
		        'container_id'		=> '',
		        'fallback_cb'		=> '',
		        'theme_location'    => 'main',
		        'menu_class'        => 'navbar-nav mr-auto mt-2 mt-lg-0',
		        'walker'  => new Walker_Quickstart_Menu(),
		    ) ); ?>
		    <?php endif; ?>
