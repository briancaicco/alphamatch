<header class="header header-regular">

	<?php get_template_part( 'templates/header-parts/header-bar' ); ?>

	<nav class="navbar navbar-expand-lg navbar-dark">
		<div class="container">
			<?php get_template_part( 'templates/header-parts/header-logo' ); ?>

			<?php get_template_part( 'templates/header-parts/header-navigation-toggle' ); ?>

			<div class="header-navigation-wrapper w-100 ">

				<?php get_template_part( 'templates/header-parts/header-user-menu' ); ?>
					
					<div class="collapse navbar-collapse" id="mainNavToggle">
						<div class="d-flex justify-content-center w-100">
							<?php get_template_part( 'templates/header-parts/header-navigation-menu' ); ?>
						</div>
					</div>

				<?php //dynamic_sidebar( 'header' ); ?>

				<?php get_template_part( 'templates/header-parts/header-action' ); ?>

			</div><!-- /.header-navigation-wrapper -->
		</div>

	</nav><!-- /.header-wrapper -->

	<?php get_template_part( 'templates/header-parts/header-post-types' ); ?>

</header><!-- /.header -->