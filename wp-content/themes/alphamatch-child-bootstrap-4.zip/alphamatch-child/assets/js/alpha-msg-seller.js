jQuery(document).ready(function($) {
	'use strict';


            //         // Form adjustments
            // $('.fep-form-field-message_title, .fep-form-field-fep-message-to').css('display', 'none')
            // $('#fep-message-to').css('display', 'none');
            // $('#fep-message-top, #fep-message-to').attr({
            // 'class' : 'hidden',
            // 'value' : '<?php echo $seller_name; ?>'           
            // }),
            // $('#message_title').attr({
            // 'class' : 'hidden',
            // 'value' : '<?php echo $post_title; ?>'           
            // }),
            // // $('#token').attr({
            // // 'value' : null          
            // // }),
            // $('.front-end-pm-form form').attr({
            // 'action' : null           
            // })
            // if( $('.fep-success').text().length != 0 ){
            //     $('#msg-seller-btn').html("Message successfully sent.");
            //     $('.fep-success').css('display', 'none');
            // }else if ( $('.fep-error').text().length != 0 ){
            //     //$('.fep-error').clone().appendTo('#msg-seller-btn');
            //     $('#msg-seller-btn').html($('.fep-error').html());
            //     $('#msg-seller-btn').addClass('btn-danger');
            //     $('.fep-error').css('display', 'none');
            // }

});