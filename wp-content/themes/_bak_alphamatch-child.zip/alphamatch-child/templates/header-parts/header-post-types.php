<?php if ( class_exists( 'Inventor_Post_Types' ) ) : ?>
    <div class="">
        <div class="collapse search-box" id="collapseSearch">
            <div class="container-fluid bg-white">
                <div class="row">
                    <div class="container">
                        <div class="col-12">
                            <?php get_search_form(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div><!-- /.container -->
    </div><!-- /.header-post-types -->
<?php endif; ?>